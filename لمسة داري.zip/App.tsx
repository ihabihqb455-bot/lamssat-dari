/**
 * Z&Z MDF Meuble — Single-file React + Vite e-commerce app.
 *
 * Requirements:
 *   npm i react-router-dom lucide-react
 *   Tailwind CSS configured (default config is enough — uses arbitrary hex values).
 *
 * Setup:
 *   1. Put this file at src/App.tsx and render <App /> from src/main.tsx.
 *   2. Place the product/category images in the public/images folder
 *      (e.g. public/images/hero.png). Paths below are absolute ("/images/..").
 *   3. Import a font (Inter/Poppins) in index.html or index.css if desired.
 */

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import {
  BrowserRouter,
  Link,
  NavLink,
  Route,
  Routes,
  useNavigate,
  useParams,
} from 'react-router-dom'
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CreditCard,
  Lock,
  Mail,
  MapPin,
  Menu,
  Minus,
  Phone,
  Plus,
  ShoppingCart,
  Trash2,
  X,
} from 'lucide-react'

/* ------------------------------------------------------------------ */
/* Data                                                                */
/* ------------------------------------------------------------------ */

type CategorySlug = 'dressing' | 'cuisine' | 'chambre' | 'bureau'

type Product = {
  id: string
  name: string
  category: CategorySlug
  price: number // in DH
  image: string
  description: string
  inStock: boolean
}

const categories: { slug: CategorySlug; label: string; image: string }[] = [
  { slug: 'dressing', label: 'DRESSING', image: '/images/cat-dressing.png' },
  { slug: 'cuisine', label: 'CUISINE', image: '/images/cat-cuisine.png' },
  { slug: 'chambre', label: 'CHAMBRE', image: '/images/cat-chambre.png' },
  { slug: 'bureau', label: 'BUREAU', image: '/images/cat-bureau.png' },
]

const categoryLabel = (slug: CategorySlug) =>
  categories.find((c) => c.slug === slug)?.label ?? slug

const products: Product[] = [
  {
    id: 'armoire-dressing',
    name: 'Armoire Dressing Moderne',
    category: 'dressing',
    price: 8900,
    image: '/images/p-armoire-dressing.png',
    description:
      'Armoire dressing en MDF haute densité avec portes coulissantes, finition beige bois chaleureuse et rangements modulables.',
    inStock: true,
  },
  {
    id: 'dressing-angle',
    name: "Dressing d'Angle Sur-Mesure",
    category: 'dressing',
    price: 12400,
    image: '/images/p-dressing-angle.png',
    description:
      "Dressing d'angle ouvert optimisant chaque recoin, étagères réglables et penderie intégrée en MDF.",
    inStock: false,
  },
  {
    id: 'cuisine-complet',
    name: 'Meuble Cuisine Complet',
    category: 'cuisine',
    price: 21500,
    image: '/images/p-cuisine-complet.png',
    description:
      'Ensemble cuisine complet en MDF laqué, plan de travail noir et caissons résistants à l’humidité.',
    inStock: true,
  },
  {
    id: 'ilot-cuisine',
    name: 'Îlot Central Cuisine',
    category: 'cuisine',
    price: 9800,
    image: '/images/p-ilot-cuisine.png',
    description:
      'Îlot central multifonction avec plan en pierre noire, rangements généreux et finition bois beige.',
    inStock: true,
  },
  {
    id: 'lit-coffre',
    name: 'Lit Coffre avec Rangement',
    category: 'chambre',
    price: 6700,
    image: '/images/p-lit-coffre.png',
    description:
      'Lit coffre avec tête de lit en MDF et grand espace de rangement sous le sommier.',
    inStock: true,
  },
  {
    id: 'commode-6-tiroirs',
    name: 'Commode 6 Tiroirs',
    category: 'chambre',
    price: 3200,
    image: '/images/p-commode.png',
    description:
      'Commode élégante à 6 tiroirs sur glissières, finition beige bois et poignées discrètes.',
    inStock: false,
  },
  {
    id: 'bureau-directeur',
    name: 'Bureau Directeur MDF',
    category: 'bureau',
    price: 5400,
    image: '/images/p-bureau-directeur.png',
    description:
      'Bureau directeur spacieux avec caisson intégré, finition bois beige et détails noirs.',
    inStock: true,
  },
  {
    id: 'bibliotheque',
    name: 'Bibliothèque Modulable',
    category: 'bureau',
    price: 4600,
    image: '/images/p-bibliotheque.png',
    description:
      'Bibliothèque modulable en MDF, étagères ajustables pour un rangement sur-mesure.',
    inStock: true,
  },
]

const getProductsByCategory = (slug: CategorySlug) =>
  products.filter((p) => p.category === slug)

const formatDH = (value: number) =>
  `${value.toLocaleString('fr-MA').replace(/\u202f/g, ' ')} DH`

/* ------------------------------------------------------------------ */
/* Cart state (React Context + localStorage)                           */
/* ------------------------------------------------------------------ */

type CartItem = {
  id: string
  name: string
  price: number
  image: string
  quantity: number
}

type CartContextValue = {
  items: CartItem[]
  totalQuantity: number
  subtotal: number
  addItem: (product: Product) => void
  removeItem: (id: string) => void
  increment: (id: string) => void
  decrement: (id: string) => void
  clear: () => void
}

const CartContext = createContext<CartContextValue | null>(null)

const STORAGE_KEY = 'zz-mdf-cart'

function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    if (typeof window === 'undefined') return []
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY)
      return raw ? (JSON.parse(raw) as CartItem[]) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
    } catch {
      /* ignore write errors */
    }
  }, [items])

  const addItem = (product: Product) =>
    setItems((prev) => {
      const existing = prev.find((i) => i.id === product.id)
      if (existing) {
        return prev.map((i) =>
          i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i,
        )
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          quantity: 1,
        },
      ]
    })

  const removeItem = (id: string) =>
    setItems((prev) => prev.filter((i) => i.id !== id))

  const increment = (id: string) =>
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, quantity: i.quantity + 1 } : i)),
    )

  const decrement = (id: string) =>
    setItems((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, quantity: i.quantity - 1 } : i))
        .filter((i) => i.quantity > 0),
    )

  const clear = () => setItems([])

  const value = useMemo<CartContextValue>(() => {
    const totalQuantity = items.reduce((s, i) => s + i.quantity, 0)
    const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0)
    return {
      items,
      totalQuantity,
      subtotal,
      addItem,
      removeItem,
      increment,
      decrement,
      clear,
    }
  }, [items])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}

/* ------------------------------------------------------------------ */
/* Shared UI primitives                                                */
/* ------------------------------------------------------------------ */

const BEIGE = '#D2B48C'
const INK = '#111111'

const navLinks = [
  { to: '/', label: 'Accueil', end: true },
  { to: '/boutique', label: 'Boutique' },
  { to: '/dressing', label: 'Dressing' },
  { to: '/cuisine', label: 'Cuisine' },
  { to: '/chambre', label: 'Chambre' },
  { to: '/bureau', label: 'Bureau' },
  { to: '/contact', label: 'Contact' },
]

function Header() {
  const { totalQuantity } = useCart()
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-neutral-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex flex-col leading-none">
          <span
            className="text-2xl font-extrabold tracking-tight text-[#111111]"
            style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
          >
            Z&amp;Z
          </span>
          <span className="text-xs font-semibold tracking-[0.25em] text-[#D2B48C]">
            MDF MEUBLE
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {navLinks.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `text-base font-semibold transition-colors ${
                  isActive
                    ? 'text-[#111111]'
                    : 'text-neutral-500 hover:text-[#111111]'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/panier"
            aria-label="Voir le panier"
            className="relative flex h-11 w-11 items-center justify-center rounded-full border border-neutral-200 text-[#111111] transition-colors hover:bg-neutral-100"
          >
            <ShoppingCart className="h-5 w-5" />
            {totalQuantity > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#111111] px-1 text-xs font-bold text-white">
                {totalQuantity}
              </span>
            )}
          </Link>
          <button
            type="button"
            aria-label="Menu"
            onClick={() => setOpen((v) => !v)}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-neutral-200 text-[#111111] lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-neutral-200 bg-white lg:hidden">
          <div className="mx-auto flex max-w-7xl flex-col px-4 py-2 sm:px-6">
            {navLinks.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `py-3 text-base font-semibold ${
                    isActive ? 'text-[#111111]' : 'text-neutral-500'
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </div>
        </nav>
      )}
    </header>
  )
}

function Footer() {
  return (
    <footer className="mt-20 border-t border-neutral-200 bg-[#111111] text-neutral-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3 lg:px-8">
        <div>
          <span
            className="text-2xl font-extrabold text-white"
            style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
          >
            Z&amp;Z <span className="text-[#D2B48C]">MDF Meuble</span>
          </span>
          <p className="mt-4 max-w-xs text-base leading-relaxed">
            Meubles en MDF sur-mesure : dressing, cuisine, chambre et bureau.
            Fabrication de qualité, finitions haut de gamme.
          </p>
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Catégories</h3>
          <ul className="mt-4 space-y-2 text-base">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link
                  to={`/${c.slug}`}
                  className="transition-colors hover:text-[#D2B48C]"
                >
                  {c.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Contact</h3>
          <ul className="mt-4 space-y-3 text-base">
            <li className="flex items-center gap-3">
              <Phone className="h-5 w-5 text-[#D2B48C]" /> +212 6 00 00 00 00
            </li>
            <li className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-[#D2B48C]" /> contact@zzmdf.ma
            </li>
            <li className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-[#D2B48C]" /> Casablanca, Maroc
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-6 text-center text-sm">
        © {new Date().getFullYear()} Z&amp;Z MDF Meuble. Tous droits réservés.
      </div>
    </footer>
  )
}

function CategoryTiles() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {categories.map((c) => (
        <Link
          key={c.slug}
          to={`/${c.slug}`}
          className="group relative flex h-44 items-center justify-center overflow-hidden rounded-xl"
        >
          <img
            src={c.image || '/placeholder.svg'}
            alt={c.label}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <span className="absolute inset-0 bg-black/50 transition-colors group-hover:bg-black/40" />
          <span className="relative text-[22px] font-bold tracking-wide text-white">
            {c.label}
          </span>
        </Link>
      ))}
    </div>
  )
}

function StockBadge({ inStock }: { inStock: boolean }) {
  return inStock ? (
    <span className="inline-flex items-center gap-1.5 text-base font-semibold text-[#22C55E]">
      <span className="h-2.5 w-2.5 rounded-full bg-[#22C55E]" /> Disponible
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 text-base font-semibold text-[#EF4444]">
      <span className="h-2.5 w-2.5 rounded-full bg-[#EF4444]" /> Rupture de stock
    </span>
  )
}

function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart()
  return (
    <article className="flex flex-col overflow-hidden rounded-xl border border-neutral-200 bg-white transition-shadow hover:shadow-lg">
      <div className="relative aspect-[4/3] overflow-hidden bg-neutral-100">
        <img
          src={product.image || '/placeholder.svg'}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <span className="absolute left-3 top-3 rounded-full bg-[#D2B48C] px-3 py-1 text-xs font-bold uppercase tracking-wide text-[#111111]">
          {categoryLabel(product.category)}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-xl font-bold text-[#111111]">{product.name}</h3>
        <p className="mt-2 flex-1 text-base leading-relaxed text-neutral-600">
          {product.description}
        </p>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xl font-bold text-[#111111]">
            {formatDH(product.price)}
          </span>
          <StockBadge inStock={product.inStock} />
        </div>
        <button
          type="button"
          disabled={!product.inStock}
          onClick={() => addItem(product)}
          className={`mt-5 flex h-12 items-center justify-center gap-2 rounded-md text-base font-bold transition-colors ${
            product.inStock
              ? 'bg-[#111111] text-white hover:bg-[#111111]/90'
              : 'cursor-not-allowed bg-neutral-200 text-neutral-400'
          }`}
        >
          <ShoppingCart className="h-5 w-5" />
          {product.inStock ? 'Ajouter au panier' : 'Indisponible'}
        </button>
      </div>
    </article>
  )
}

function ProductGrid({ items }: { items: Product[] }) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {items.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  )
}

function PageHeader({
  title,
  subtitle,
}: {
  title: string
  subtitle?: string
}) {
  return (
    <div className="border-b border-neutral-200 bg-[#D2B48C]/15">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <h1
          className="text-4xl font-extrabold text-[#111111]"
          style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
        >
          {title}
        </h1>
        {subtitle && (
          <p className="mt-3 max-w-2xl text-lg text-neutral-600">{subtitle}</p>
        )}
      </div>
    </div>
  )
}

function CardBrands() {
  return (
    <div className="flex items-center gap-2">
      <span className="flex h-8 items-center rounded-md border border-neutral-200 bg-white px-2.5 text-sm font-bold italic tracking-tight text-[#1a1f71]">
        VISA
      </span>
      <span className="flex h-8 items-center gap-1 rounded-md border border-neutral-200 bg-white px-2.5">
        <span className="h-4 w-4 rounded-full bg-[#eb001b]" />
        <span className="-ml-2 h-4 w-4 rounded-full bg-[#f79e1b] opacity-90" />
      </span>
      <span className="flex h-8 items-center rounded-md border border-neutral-200 bg-white px-2.5 text-sm font-bold tracking-tight text-[#c8102e]">
        CMI
      </span>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Pages                                                               */
/* ------------------------------------------------------------------ */

function HomePage() {
  const featured = products.filter((p) => p.inStock).slice(0, 4)
  return (
    <div>
      {/* Hero */}
      <section className="relative">
        <div className="relative h-[70vh] min-h-[440px] w-full overflow-hidden">
          <img
            src="/images/hero.png"
            alt="Meubles MDF Z&Z"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-black/55" />
          <div className="absolute inset-0 flex items-center">
            <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="max-w-2xl">
                <span className="text-sm font-bold uppercase tracking-[0.3em] text-[#D2B48C]">
                  Meubles MDF sur-mesure
                </span>
                <h1
                  className="mt-4 text-4xl font-extrabold leading-tight text-white sm:text-5xl lg:text-6xl"
                  style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
                >
                  L&apos;élégance du bois, façonnée pour votre intérieur
                </h1>
                <p className="mt-5 text-lg leading-relaxed text-neutral-200">
                  Dressing, cuisine, chambre et bureau. Des meubles en MDF haut
                  de gamme, conçus et fabriqués avec précision à Casablanca.
                </p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Link
                    to="/boutique"
                    className="flex h-12 items-center gap-2 rounded-md bg-[#D2B48C] px-7 text-base font-bold text-[#111111] transition-colors hover:bg-[#D2B48C]/90"
                  >
                    Découvrir la boutique <ArrowRight className="h-5 w-5" />
                  </Link>
                  <Link
                    to="/contact"
                    className="flex h-12 items-center rounded-md border border-white/60 px-7 text-base font-bold text-white transition-colors hover:bg-white/10"
                  >
                    Nous contacter
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2
              className="text-3xl font-extrabold text-[#111111]"
              style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
            >
              Nos catégories
            </h2>
            <p className="mt-2 text-lg text-neutral-600">
              Trouvez le meuble parfait pour chaque pièce.
            </p>
          </div>
        </div>
        <CategoryTiles />
      </section>

      {/* Featured products */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-end justify-between">
          <h2
            className="text-3xl font-extrabold text-[#111111]"
            style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
          >
            Produits en vedette
          </h2>
          <Link
            to="/boutique"
            className="flex items-center gap-2 text-base font-bold text-[#111111] hover:text-[#D2B48C]"
          >
            Tout voir <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
        <ProductGrid items={featured} />
      </section>
    </div>
  )
}

function BoutiquePage() {
  return (
    <div>
      <PageHeader
        title="Boutique"
        subtitle="Toute notre collection de meubles MDF sur-mesure."
      />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <ProductGrid items={products} />
      </div>
    </div>
  )
}

function CategoryPage({ slug }: { slug: CategorySlug }) {
  const items = getProductsByCategory(slug)
  return (
    <div>
      <PageHeader
        title={categoryLabel(slug)}
        subtitle={`Notre sélection ${categoryLabel(slug).toLowerCase()} en MDF.`}
      />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {items.length > 0 ? (
          <ProductGrid items={items} />
        ) : (
          <p className="text-lg text-neutral-600">
            Aucun produit dans cette catégorie pour le moment.
          </p>
        )}
      </div>
    </div>
  )
}

/** Reads the :slug param so category routes share one component. */
function CategoryRoute() {
  const { slug } = useParams<{ slug: CategorySlug }>()
  return <CategoryPage slug={(slug as CategorySlug) ?? 'dressing'} />
}

function ContactPage() {
  const [sent, setSent] = useState(false)
  const inputClass =
    'h-12 w-full rounded-md border border-neutral-300 bg-white px-4 text-base outline-none transition-colors focus:border-[#D2B48C] focus:ring-2 focus:ring-[#D2B48C]/40'
  return (
    <div>
      <PageHeader
        title="Contact"
        subtitle="Une question, un projet sur-mesure ? Écrivez-nous."
      />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:px-8">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            setSent(true)
          }}
          className="rounded-xl border border-neutral-200 bg-white p-6 sm:p-8"
        >
          {sent ? (
            <div className="flex flex-col items-center py-10 text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[#22C55E] text-white">
                <Check className="h-7 w-7" />
              </span>
              <h2 className="mt-5 text-2xl font-bold text-[#111111]">
                Message envoyé
              </h2>
              <p className="mt-2 text-lg text-neutral-600">
                Merci ! Nous vous répondrons dans les plus brefs délais.
              </p>
            </div>
          ) : (
            <div className="grid gap-5">
              <div className="grid gap-2">
                <label className="text-base font-semibold" htmlFor="c-name">
                  Nom complet
                </label>
                <input id="c-name" required className={inputClass} />
              </div>
              <div className="grid gap-2">
                <label className="text-base font-semibold" htmlFor="c-email">
                  Email
                </label>
                <input
                  id="c-email"
                  type="email"
                  required
                  className={inputClass}
                />
              </div>
              <div className="grid gap-2">
                <label className="text-base font-semibold" htmlFor="c-msg">
                  Message
                </label>
                <textarea
                  id="c-msg"
                  required
                  rows={5}
                  className="w-full rounded-md border border-neutral-300 bg-white px-4 py-3 text-base outline-none transition-colors focus:border-[#D2B48C] focus:ring-2 focus:ring-[#D2B48C]/40"
                />
              </div>
              <button
                type="submit"
                className="flex h-12 items-center justify-center rounded-md bg-[#111111] text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
              >
                Envoyer le message
              </button>
            </div>
          )}
        </form>
        <div className="flex flex-col gap-6">
          <div className="rounded-xl border border-neutral-200 bg-[#D2B48C]/15 p-6">
            <h2 className="text-2xl font-bold text-[#111111]">Coordonnées</h2>
            <ul className="mt-4 space-y-3 text-lg text-neutral-700">
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-[#111111]" /> +212 6 00 00 00 00
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-[#111111]" /> contact@zzmdf.ma
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-[#111111]" /> Casablanca, Maroc
              </li>
            </ul>
          </div>
          <div className="rounded-xl border border-neutral-200 bg-white p-6">
            <h3 className="text-xl font-bold text-[#111111]">
              Horaires d&apos;ouverture
            </h3>
            <p className="mt-3 text-lg leading-relaxed text-neutral-600">
              Lundi – Samedi : 9h00 – 19h00
              <br />
              Dimanche : Fermé
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function PanierPage() {
  const { items, totalQuantity, subtotal, increment, decrement, removeItem } =
    useCart()

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-24 text-center">
        <ShoppingCart className="h-14 w-14 text-neutral-300" />
        <h1 className="mt-6 text-3xl font-bold text-[#111111]">
          Votre panier est vide
        </h1>
        <p className="mt-3 text-lg text-neutral-600">
          Parcourez notre boutique et ajoutez vos meubles préférés.
        </p>
        <Link
          to="/boutique"
          className="mt-8 flex h-12 items-center rounded-md bg-[#111111] px-6 text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
        >
          Aller à la boutique
        </Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1
        className="text-4xl font-extrabold text-[#111111]"
        style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
      >
        Mon panier
      </h1>
      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]">
        <ul className="divide-y divide-neutral-200 rounded-xl border border-neutral-200 bg-white">
          {items.map((item) => (
            <li key={item.id} className="flex gap-4 p-4 sm:p-5">
              <img
                src={item.image || '/placeholder.svg'}
                alt={item.name}
                className="h-24 w-24 flex-shrink-0 rounded-md object-cover"
              />
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-lg font-bold text-[#111111]">
                    {item.name}
                  </h3>
                  <button
                    type="button"
                    onClick={() => removeItem(item.id)}
                    aria-label={`Retirer ${item.name}`}
                    className="text-neutral-400 transition-colors hover:text-[#EF4444]"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
                <span className="mt-1 text-base text-neutral-600">
                  {formatDH(item.price)} l&apos;unité
                </span>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => decrement(item.id)}
                      aria-label="Diminuer la quantité"
                      className="flex h-9 w-9 items-center justify-center rounded-md border border-neutral-300 text-[#111111] transition-colors hover:bg-neutral-100"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-8 text-center text-lg font-bold">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => increment(item.id)}
                      aria-label="Augmenter la quantité"
                      className="flex h-9 w-9 items-center justify-center rounded-md border border-neutral-300 text-[#111111] transition-colors hover:bg-neutral-100"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <span className="text-lg font-bold text-[#111111]">
                    {formatDH(item.price * item.quantity)}
                  </span>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <aside className="h-fit rounded-xl border border-neutral-200 bg-[#D2B48C]/15 p-6">
          <h2 className="text-2xl font-bold text-[#111111]">Récapitulatif</h2>
          <dl className="mt-5 space-y-3 text-base">
            <div className="flex items-center justify-between">
              <dt className="text-neutral-600">
                Quantité totale
              </dt>
              <dd className="font-semibold">{totalQuantity}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-neutral-600">Sous-total</dt>
              <dd className="font-semibold">{formatDH(subtotal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-neutral-600">Livraison</dt>
              <dd className="font-semibold text-[#22C55E]">Gratuite</dd>
            </div>
          </dl>
          <div className="mt-4 flex items-center justify-between border-t border-neutral-300 pt-4">
            <span className="text-lg font-bold">Total</span>
            <span
              className="text-2xl font-extrabold text-[#111111]"
              style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
            >
              {formatDH(subtotal)}
            </span>
          </div>
          <Link
            to="/checkout"
            className="mt-6 flex h-12 items-center justify-center gap-2 rounded-md bg-[#111111] text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
          >
            Passer au paiement <ArrowRight className="h-5 w-5" />
          </Link>
        </aside>
      </div>
    </div>
  )
}

function CheckoutPage() {
  const { items, subtotal, totalQuantity, clear } = useCart()
  const navigate = useNavigate()
  const [paid, setPaid] = useState(false)

  const [cardName, setCardName] = useState('')
  const [cardNumber, setCardNumber] = useState('')
  const [expiry, setExpiry] = useState('')
  const [cvv, setCvv] = useState('')

  const inputClass =
    'h-12 w-full rounded-md border border-neutral-300 bg-white px-4 text-base outline-none transition-colors focus:border-[#D2B48C] focus:ring-2 focus:ring-[#D2B48C]/40'

  const handleCardNumber = (v: string) => {
    const digits = v.replace(/\D/g, '').slice(0, 16)
    setCardNumber(digits.replace(/(.{4})/g, '$1 ').trim())
  }
  const handleExpiry = (v: string) => {
    const digits = v.replace(/\D/g, '').slice(0, 4)
    setExpiry(digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits)
  }
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setPaid(true)
    clear()
  }

  if (paid) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-24 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-[#22C55E] text-white">
          <Check className="h-8 w-8" />
        </span>
        <h1 className="mt-6 text-3xl font-bold text-[#111111]">
          Paiement confirmé
        </h1>
        <p className="mt-3 text-lg text-neutral-600">
          Merci pour votre commande ! Un conseiller Z&amp;Z MDF Meuble vous
          contactera pour organiser la livraison.
        </p>
        <button
          type="button"
          onClick={() => navigate('/')}
          className="mt-8 flex h-12 items-center rounded-md bg-[#111111] px-6 text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
        >
          Retour à l&apos;accueil
        </button>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-24 text-center">
        <h1 className="text-3xl font-bold text-[#111111]">
          Aucun article à régler
        </h1>
        <p className="mt-3 text-lg text-neutral-600">
          Ajoutez des produits à votre panier avant de passer au paiement.
        </p>
        <Link
          to="/boutique"
          className="mt-8 flex h-12 items-center rounded-md bg-[#111111] px-6 text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
        >
          Aller à la boutique
        </Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <Link
        to="/panier"
        className="inline-flex items-center gap-2 text-base font-semibold text-neutral-500 hover:text-[#111111]"
      >
        <ArrowLeft className="h-5 w-5" /> Retour au panier
      </Link>
      <h1
        className="mt-4 text-4xl font-extrabold text-[#111111]"
        style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
      >
        Paiement
      </h1>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]">
        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-neutral-200 bg-white p-6 sm:p-8"
        >
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-2xl font-bold text-[#111111]">
              <CreditCard className="h-6 w-6" /> Carte bancaire
            </h2>
            <CardBrands />
          </div>

          <div className="mt-6 grid gap-5">
            <div className="grid gap-2">
              <label htmlFor="cardName" className="text-base font-semibold">
                Nom sur la carte
              </label>
              <input
                id="cardName"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                placeholder="ZAKARIA ZAHIRI"
                required
                className={inputClass}
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="cardNumber" className="text-base font-semibold">
                Numéro de carte
              </label>
              <input
                id="cardNumber"
                inputMode="numeric"
                value={cardNumber}
                onChange={(e) => handleCardNumber(e.target.value)}
                placeholder="0000 0000 0000 0000"
                required
                className={inputClass}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="expiry" className="text-base font-semibold">
                  Date d&apos;expiration
                </label>
                <input
                  id="expiry"
                  inputMode="numeric"
                  value={expiry}
                  onChange={(e) => handleExpiry(e.target.value)}
                  placeholder="MM/AA"
                  required
                  className={inputClass}
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="cvv" className="text-base font-semibold">
                  CVV
                </label>
                <input
                  id="cvv"
                  inputMode="numeric"
                  value={cvv}
                  onChange={(e) =>
                    setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))
                  }
                  placeholder="123"
                  required
                  className={inputClass}
                />
              </div>
            </div>
            <button
              type="submit"
              className="mt-2 flex items-center justify-center gap-2 rounded-md bg-[#111111] py-3.5 text-lg font-bold text-white transition-colors hover:bg-[#111111]/90"
            >
              <Lock className="h-5 w-5" /> Payer {formatDH(subtotal)}
            </button>
            <p className="flex items-center justify-center gap-2 text-sm text-neutral-500">
              <Lock className="h-4 w-4" /> Paiement 100% sécurisé — démonstration
              UI
            </p>
          </div>
        </form>

        <aside className="h-fit rounded-xl border border-neutral-200 bg-[#D2B48C]/15 p-6">
          <h2 className="text-2xl font-bold text-[#111111]">Votre commande</h2>
          <ul className="mt-5 space-y-3 text-base">
            {items.map((item) => (
              <li key={item.id} className="flex items-start justify-between gap-3">
                <span className="text-neutral-600">
                  {item.name}{' '}
                  <span className="font-semibold text-[#111111]">
                    × {item.quantity}
                  </span>
                </span>
                <span className="whitespace-nowrap font-semibold">
                  {formatDH(item.price * item.quantity)}
                </span>
              </li>
            ))}
          </ul>
          <dl className="mt-5 space-y-3 border-t border-neutral-300 pt-5 text-base">
            <div className="flex items-center justify-between">
              <dt className="text-neutral-600">Articles ({totalQuantity})</dt>
              <dd className="font-semibold">{formatDH(subtotal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-neutral-600">Livraison</dt>
              <dd className="font-semibold text-[#22C55E]">Gratuite</dd>
            </div>
          </dl>
          <div className="mt-4 flex items-center justify-between border-t border-neutral-300 pt-4">
            <span className="text-lg font-bold">Total à payer</span>
            <span
              className="text-2xl font-extrabold text-[#111111]"
              style={{ fontFamily: 'Poppins, Inter, sans-serif' }}
            >
              {formatDH(subtotal)}
            </span>
          </div>
        </aside>
      </div>
    </div>
  )
}

function NotFoundPage() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-4 py-24 text-center">
      <h1 className="text-5xl font-extrabold text-[#111111]">404</h1>
      <p className="mt-3 text-lg text-neutral-600">
        Cette page n&apos;existe pas.
      </p>
      <Link
        to="/"
        className="mt-8 flex h-12 items-center rounded-md bg-[#111111] px-6 text-base font-bold text-white transition-colors hover:bg-[#111111]/90"
      >
        Retour à l&apos;accueil
      </Link>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* App shell + routing                                                 */
/* ------------------------------------------------------------------ */

function Layout({ children }: { children: ReactNode }) {
  return (
    <div
      className="flex min-h-screen flex-col bg-white text-[#111111]"
      style={{ fontFamily: 'Inter, system-ui, sans-serif' }}
    >
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}

export default function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/boutique" element={<BoutiquePage />} />
            <Route path="/dressing" element={<CategoryPage slug="dressing" />} />
            <Route path="/cuisine" element={<CategoryPage slug="cuisine" />} />
            <Route path="/chambre" element={<CategoryPage slug="chambre" />} />
            <Route path="/bureau" element={<CategoryPage slug="bureau" />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/panier" element={<PanierPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </CartProvider>
  )
}
